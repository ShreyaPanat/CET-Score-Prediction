import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, accuracy_score
from sklearn.impute import SimpleImputer

# Load the data from CSV file
df = pd.read_csv('data.csv')

# Display the first few rows and summary of the dataframe
print(df.head())
print(df.info())  # Check for missing values

# Identify missing values
print(df.isnull().sum())

# Handle missing values
# For the target variable `admitted`, remove rows with missing values
df = df.dropna(subset=['admitted'])

# For features, handle missing values (imputation)
# Impute missing values in features
X = df[['college_name', 'branch', 'cutoff_percentile', 'student_percentile']]
y = df['admitted']

# Preprocessing
preprocessor = ColumnTransformer(
    transformers=[
        ('cat', Pipeline(steps=[
            ('imputer', SimpleImputer(strategy='most_frequent')),  # Impute missing categorical data
            ('encoder', OneHotEncoder(handle_unknown='ignore'))
        ]), ['college_name', 'branch']),
        ('num', Pipeline(steps=[
            ('imputer', SimpleImputer(strategy='mean')),  # Impute missing numerical data
            ('scaler', StandardScaler())
        ]), ['cutoff_percentile', 'student_percentile'])
    ]
)

# Create a pipeline with preprocessing and logistic regression
model = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('classifier', LogisticRegression())
])

# Split data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train the model
model.fit(X_train, y_train)

# Make predictions
y_pred = model.predict(X_test)

# Evaluate the model
print(f'Accuracy: {accuracy_score(y_test, y_pred)}')
print('Classification Report:')
print(classification_report(y_test, y_pred))
