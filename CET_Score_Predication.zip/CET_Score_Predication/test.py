import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.impute import SimpleImputer

# Load the data
df = pd.read_csv('data.csv')

# Drop rows with missing target values
df = df.dropna(subset=['admitted'])

# Define features and target
X = df[['college_name', 'branch', 'cutoff_percentile', 'student_percentile']]
y = df['admitted']

# Preprocessing
preprocessor = ColumnTransformer(
    transformers=[
        ('cat', Pipeline(steps=[
            ('imputer', SimpleImputer(strategy='most_frequent')),  # Impute missing categorical data
            ('encoder', OneHotEncoder(handle_unknown='ignore'))
        ]), ['college_name', 'branch']),
        ('num', Pipeline(steps=[
            ('imputer', SimpleImputer(strategy='mean')),  # Impute missing numerical data
            ('scaler', StandardScaler())
        ]), ['cutoff_percentile', 'student_percentile'])
    ]
)


# Create a pipeline with preprocessing and logistic regression
model = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('classifier', LogisticRegression())
])

# Split data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train the model
model.fit(X_train, y_train)



def suggest_colleges(student_percentile, branch, df, model):
    # Prepare input data
    input_data = pd.DataFrame({
        'college_name': df['college_name'].unique(),
        'branch': [branch] * len(df['college_name'].unique()),
        'cutoff_percentile': df['cutoff_percentile'].mean(),  # Example: use average cutoff percentile
        'student_percentile': [student_percentile] * len(df['college_name'].unique())
    })

    # Predict the probability of admission for each college
    probabilities = model.predict_proba(input_data)[:, 1]

    # Add probabilities to the original DataFrame
    suggestions = df[['college_name']].drop_duplicates()
    suggestions['admission_probability'] = probabilities

    # Sort by probability in descending order
    suggestions = suggestions.sort_values(by='admission_probability', ascending=False)

    return suggestions

# Example usage
student_percentile = 85
branch = 'Computer Science'
suggested_colleges = suggest_colleges(student_percentile, branch, df, model)
print(suggested_colleges)
