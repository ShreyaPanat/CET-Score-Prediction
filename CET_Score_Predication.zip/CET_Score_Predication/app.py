import datetime
import os
import urllib
import MySQLdb.cursors
from flask import *
from flask import Flask, render_template,request,session,url_for,redirect,flash, send_file
from flask_mysqldb import MySQL
from werkzeug.utils import secure_filename
from io import BytesIO
from datetime import datetime
import time
import subprocess

import numpy as np
from sklearn.linear_model import LinearRegression
import csv
from werkzeug.utils import secure_filename

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.impute import SimpleImputer

app = Flask(__name__, static_folder='Static', static_url_path='/Static')
# Assuming you have a static folder for file uploads
UPLOAD_FOLDER = 'static/upload_img'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

app.secret_key = 'Pob'

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'cet_college'
mysql = MySQL(app)



@app.route('/')
def index():
    return render_template('index1.html')



@app.route('/login',methods=['GET', 'POST'])
def login():
    error = None

    if request.method == "POST":
        username = request.form['txtusername']
        password = request.form['txtpass']

        # Check if the provided username and password match your database records
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM signup WHERE uname = %s AND pass = %s", (username, password))
        user = cur.fetchone()
        cur.close()

        if user:
            session['username'] = username
            flash("You are Login Successfully!!")

            user_dict = {'uname': user[0], 'uimg': user[1]}

            cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
            cur.execute("SELECT uname, uimg FROM signup WHERE uname=%s", (username,))
            # cur.execute("SELECT * FROM signup WHERE uname=%s", (uname,))
            ulist = cur.fetchall()
            cur.close()

            return render_template('user_index.html', uname=username, user=user_dict, ulist=ulist, error=error)

        else:
            error = "Invalid username and password"
            # return "Invalid username or password"

    return render_template('login.html')


@app.route('/signup',methods=['GET', 'POST'])
def signup():
    error = None
    if request.method == "POST":
        fullname = request.form['txtfullname']
        username = request.form['txtusername']
        email = request.form['txtemail']

        password = request.form['txtpass']
        userimage = request.files['file']

        if not username or not email or not password or not fullname:
            flash("Please fill in all required fields.")
        else:
            # Check if the username is already taken
            cur = mysql.connection.cursor()
            cur.execute("SELECT COUNT(*) FROM signup WHERE uname = %s", (username,))
            count = cur.fetchone()[0]
            cur.close()

            if count > 0:
                flash("Username is already taken. Please choose a different one.")
            else:
                    cur = mysql.connection.cursor()
                    cur.execute("INSERT INTO signup (fname,uname, email, pass,uimg) VALUES ( %s, %s,%s, %s, %s)",
                                (fullname, username, email, password, userimage.filename,))
                    mysql.connection.commit()
                    cur.close()

                    userimage.save('Static/upload_img/' + userimage.filename)

                    flash("Signup successful!!")  # You can redirect to another page or show a success message.

    return render_template('signup.html')




@app.route('/user-index')
def userindex1():
    profile_uname = session.get('username')
    current_date = datetime.now().strftime("%Y-%m-%d")

    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT uname, uimg FROM signup WHERE uname=%s", (profile_uname,))
    ulist = cur.fetchall()
    cur.close()

    return render_template('user_index.html', profile_uname=profile_uname, ulist=ulist,  current_date=current_date)




# @app.route('/user-neet-score', methods=['GET', 'POST'])
# def userneetscore():
#     z = None
#     predicted_final_exam_score = None
#     profile_uname = session.get('username')
#     current_date = datetime.now().strftime("%Y-%m-%d")
#
#     cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
#     cur.execute("SELECT branch FROM branch_name")
#     branchlist = cur.fetchall()
#     cur.close()
#
#     cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
#     cur.execute("SELECT uname, uimg FROM signup WHERE uname=%s", (profile_uname,))
#     ulist = cur.fetchall()
#     cur.close()
#
#     cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
#     cur.execute("SELECT result,test_number FROM mocktest WHERE username=%s", (profile_uname,))
#     mocklist = cur.fetchall()
#     cur.close()
#
#
#
#     if request.method == "POST":
#         cast = request.form['txtcast']
#         session['cast']= cast
#         # Collect all test marks from the form
#         test_marks = [int(request.form[f'test{i}']) for i in range(1, 11)]
#
#         # Filter out zero values from the test marks
#         non_zero_test_marks = [mark for mark in test_marks if mark != 0]
#
#         # Check if any test value is greater than 720
#         if any(mark > 720 for mark in non_zero_test_marks):
#             flash("Test values must be less than or equal to 720.")
#         elif not non_zero_test_marks:
#             flash("Please fill in at least one test mark.")
#         else:
#             z = sum(non_zero_test_marks) / len(non_zero_test_marks)
#             # Flash a message to indicate the score prediction is in progress
#             flash("Please wait for the score prediction...")
#
#             # Sleep for 17 seconds before flashing the average value
#             time.sleep(17)
#
#             # start ML code (create a Logistic Regression Model - Prediction of probibility)
#
#             # Load data from CSV file
#             mock_test_results = []
#             final_exam_marks = []
#
#             with open('exam_scores01.csv', mode='r') as file:
#                 reader = csv.DictReader(file)
#                 for row in reader:
#                     mock_test_results.append(float(row['neet_mock_test_score']))
#                     final_exam_marks.append(
#                         min(float(row['final_exam_score']), 719))  # Clip the final exam marks to a maximum of 719
#
#             # Convert lists to numpy arrays
#             mock_test_results = np.array(mock_test_results)
#             final_exam_marks = np.array(final_exam_marks)
#
#             # Create and train the Linear Regression model
#             model = LinearRegression()
#             model.fit(mock_test_results.reshape(-1, 1), final_exam_marks)
#
#             # Function to predict final exam score based on mock test mark
#             def predict_final_exam_score(mock_test_mark):
#                 # Add some randomness to the input
#                 mock_test_mark += np.random.uniform(-1, 1)
#
#                 # Reshape the input to match the model's requirements
#                 mock_test_mark = np.array(mock_test_mark).reshape(1, -1)
#                 # Predict the final exam score
#                 final_exam_score = model.predict(mock_test_mark)
#                 return min(final_exam_score[0], 719)  # Clip the predicted final exam score to a maximum of 719
#
#             # Main program
#             if __name__ == "__main__":
#                 # Get user input for mock test mark
#                 mock_test_mark = float(z)
#
#                 # Predict the final exam score
#                 predicted_final_exam_score = predict_final_exam_score(mock_test_mark)
#
#                 # Print the predicted final exam score
#                 print("Predicted final exam score:", predicted_final_exam_score)
#
#             session['predicted_final_exam_score'] = predicted_final_exam_score
#
#     return render_template('user_neet_score.html',branchlist=branchlist, predicted_final_exam_score=predicted_final_exam_score, profile_uname=profile_uname, ulist=ulist, current_date=current_date, mocklist=mocklist)


@app.route('/user-score-his')
def userneethis():
    profile_uname = session.get('username')
    current_date = datetime.now().strftime("%Y-%m-%d")

    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT uname, uimg FROM signup WHERE uname=%s", (profile_uname,))
    ulist = cur.fetchall()
    cur.close()

    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT * FROM mocktest WHERE username=%s ORDER BY date DESC", (profile_uname,))
    scorelist = cur.fetchall()
    cur.close()

    return render_template('user_neet_his.html', scorelist=scorelist, profile_uname=profile_uname, ulist=ulist,  current_date=current_date)


@app.route('/loader')
def loader():
    profile_uname = session.get('username')
    current_date = datetime.now().strftime("%Y-%m-%d")

    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT uname, uimg FROM signup WHERE uname=%s", (profile_uname,))
    ulist = cur.fetchall()
    cur.close()

    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT * FROM score WHERE uname=%s", (profile_uname,))
    scorelist = cur.fetchall()
    cur.close()

    return render_template('loader.html', scorelist=scorelist, profile_uname=profile_uname, ulist=ulist,  current_date=current_date)



@app.route('/clg-list')
def clglist():
    profile_uname = session.get('username')

    current_date = datetime.now().strftime("%Y-%m-%d")

    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT uname, uimg FROM signup WHERE uname=%s", (profile_uname,))
    ulist = cur.fetchall()
    cur.close()

    cet_score = session.get('cet_score')
    # cet_score = 80
    branch = session.get('branch')

    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM cet_clg_list WHERE branch=%s AND percentile <= %s", (branch, cet_score))
    collegelist = cur.fetchall()
    cur.close()

    print(branch)
    print(collegelist)

    return render_template('user_clg_list.html',clglist=collegelist, profile_uname=profile_uname, ulist=ulist,  current_date=current_date)



@app.route('/admin-login',methods=['GET', 'POST'])
def adminlogin():
    error = None

    if request.method == "POST":
        username = request.form['txtusername']
        password = request.form['txtpass']


        if (username=='admin' and password=='star' ):
            session['username'] = username
            flash("You are Login Successfully!!")

            return redirect('/admin-index')

        else:
            error = "Invalid username and password"
            # return "Invalid username or password"

    return render_template('admin_login.html')


@app.route('/admin-index')
def adminindex():
    # Query the database to retrieve products for the logged-in user
    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT * FROM signup ")
    total_user = cur.fetchall()
    cur.close()

    total_u = len(total_user)


    return render_template('admin_index.html', total_u=total_u,)

@app.route('/admin-view-emp')
def adminviewemp():

    try:
        cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cur.execute("SELECT * FROM signup ")
        profilelist = cur.fetchall()
        cur.close()

        return render_template('admin_view_emp.html', profilelist=profilelist, )
    except Exception as e:
        return f"Error: {str(e)}"

@app.route('/admin-view-user-profile')
def adminviewuserprofile():
    profile_uname = request.args.get('uname')

    try:
        cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cur.execute("SELECT * FROM signup WHERE uname=%s", (profile_uname,))
        profilelist = cur.fetchall()
        cur.close()


        return render_template('admin_view_emp_profile.html', profilelist=profilelist, )
    except Exception as e:
        return f"Error: {str(e)}"



@app.route('/admin-update-profile', methods=['GET', 'POST'])
def adminupdateuserprofile():
    profile_uname = request.args.get('uname')

    if request.method == 'POST':
        fullname = request.form['txtfullname']
        email = request.form['txtemail']
        username = request.form['txtusername']
        password = request.form['txtpassword']
        userimage = request.files['file']

        if 'update' in request.form:
            try:
                cur = mysql.connection.cursor()

                if userimage:  # Check if an image is provided

                    cur.execute(
                        "UPDATE signup SET fname=%s, email=%s, uname=%s, pass=%s, uimg=%s WHERE uname=%s",(fullname, email, username, password, userimage.filename ,profile_uname))
                    userimage.save('Static/upload_img/' + userimage.filename)


                    print("SQL Query executed")  # Debugging statement
                else:
                    cur.execute(
                        "UPDATE signup SET fname=%s, email=%s, uname=%s, pass=%s WHERE uname=%s",(fullname, email, username, password,profile_uname))

                mysql.connection.commit()
                cur.close()
                flash(" Student updated successfully")

            except Exception as e:
                return f"Error: {str(e)}"


        elif 'delete' in request.form:
            try:
                cur = mysql.connection.cursor()
                cur.execute("DELETE FROM signup WHERE uname = %s", (profile_uname,))
                mysql.connection.commit()
                cur.close()
                flash("Student Deleted successfully")
            except Exception as e:
                return f"Error: {str(e)}"

    try:
        cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cur.execute("SELECT * FROM signup WHERE uname=%s", (profile_uname,))
        profilelist = cur.fetchall()
        cur.close()


        return render_template('admin_edit_emp.html', profilelist=profilelist,)
    except Exception as e:
        return f"Error: {str(e)}"


@app.route('/admin-view-emp-ud')
def adminviewempud():

    try:
        cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cur.execute("SELECT * FROM signup ")
        profilelist = cur.fetchall()
        cur.close()


        return render_template('admin_view_emp_update.html', profilelist=profilelist, )
    except Exception as e:
        return f"Error: {str(e)}"


@app.route('/admin-view-neet-score')
def adminviewneetscore():
    profile_uname = session.get('username')
    student_name = request.args.get('uname')
    current_date = datetime.now().strftime("%Y-%m-%d")

    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT uname, uimg FROM signup WHERE uname=%s", (profile_uname,))
    ulist = cur.fetchall()
    cur.close()



    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT * FROM mocktest WHERE username=%s ORDER BY date DESC", (student_name,))
    scorelist = cur.fetchall()
    cur.close()

    return render_template('admin_view_neet_score.html', scorelist=scorelist, profile_uname=profile_uname, ulist=ulist,  current_date=current_date)


@app.route('/admin-all-neet-score')
def adminviewallscore():

    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT * FROM mocktest ORDER BY date DESC")
    scorelist = cur.fetchall()
    cur.close()

    return render_template('admin_view_all_score.html', scorelist=scorelist)


@app.route('/service')
def servicepage():
    return render_template('service.html')

@app.route('/about')
def aboutpage():
    return render_template('about.html')


import matplotlib.pyplot as plt
import numpy as np

@app.route('/user-profile', methods=['GET', 'POST'])
def userprofile():
    profile_uname = session.get('username')

    try:
        cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cur.execute("SELECT * FROM signup WHERE uname=%s", (profile_uname,))
        profilelist = cur.fetchall()
        cur.close()

        cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cur.execute("SELECT uname, uimg FROM signup WHERE uname=%s", (profile_uname,))
        ulist = cur.fetchall()
        cur.close()

        if request.method == 'POST':
            # Check if the "View Progress Report" button is clicked
            if 'view_progress_report' in request.form:
                try:
                    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
                    cur.execute("SELECT avg FROM score WHERE uname=%s", (profile_uname,))
                    scorelist = cur.fetchall()
                    cur.close()

                    flash("Progress report is being generated. Please wait a moment.")

                    # Extracting the average scores from the result set
                    ypoint  = [score['avg'] for score in scorelist]
                    plt.plot(ypoint, marker='*', ms=20, mec='y', mfc='r')


                    plt.xlabel('Average Score')
                    plt.ylabel('Score Categories')
                    plt.title('Progress Report')
                    plt.show()

                except Exception as e:
                    flash(f"Error: {str(e)}")

        return render_template('user_profile.html', profilelist=profilelist, profile_uname=profile_uname, ulist=ulist)
    except Exception as e:
        return f"Error: {str(e)}"



@app.route('/user-profile-update',methods=['GET', 'POST'])
def userprofileupdate():
    profile_uname = session.get('username')

    if request.method == 'POST':
        fullname = request.form['txtfullname']
        email = request.form['txtemail']
        username = request.form['txtusername']
        password = request.form['txtpassword']

        imgpro = request.files['file']

        if 'update' in request.form:
            try:
                cur = mysql.connection.cursor()

                if imgpro:  # Check if an image is provided
                    cur.execute(
                        "UPDATE signup SET fname=%s, email=%s, uname=%s, pass=%s, uimg=%s WHERE uname=%s",
                        (fullname, email, username, password, imgpro.filename, profile_uname))

                    imgpro.save('Static/upload_img/' + imgpro.filename)


                    print("SQL Query executed")  # Debugging statement
                else:
                    cur.execute(
                        "UPDATE signup SET fname=%s, email=%s, uname=%s, pass=%s WHERE uname=%s",
                        (fullname, email, username, password, profile_uname))


                mysql.connection.commit()
                cur.close()
                flash("Profile updated successfully")

            except Exception as e:
                return f"Error: {str(e)}"


        elif 'delete' in request.form:
            try:
                cur = mysql.connection.cursor()
                cur.execute("DELETE FROM signup WHERE uname = %s", (profile_uname,))
                mysql.connection.commit()
                cur.close()
                flash(" Profile Deleted successfully")
            except Exception as e:
                return f"Error: {str(e)}"

    try:
        cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cur.execute("SELECT * FROM signup WHERE uname=%s", (profile_uname,))
        profilelist = cur.fetchall()
        cur.close()

        cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cur.execute("SELECT uname, uimg FROM signup WHERE uname=%s", (profile_uname,))
        # cur.execute("SELECT * FROM signup WHERE uname=%s", (uname,))
        ulist = cur.fetchall()
        cur.close()

        return render_template('user_profile_update.html', profilelist=profilelist, profile_uname=profile_uname, ulist=ulist)
    except Exception as e:
        return f"Error: {str(e)}"

    #return render_template('user_profile_update.html')



@app.route('/user_view_mock')
def user_view_mock():
    profile_uname = session.get('username')

    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT uname, uimg FROM signup WHERE uname=%s", (profile_uname,))
    ulist = cur.fetchall()
    cur.close()

    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT * FROM mocktest ")
    mocklist = cur.fetchall()
    cur.close()

    return render_template('user_view_mock.html',ulist=ulist, mocklist=mocklist)


# @app.route('/user_mock_test', methods=['GET', 'POST'])
# def user_mock_test():
#     test_number = request.args.get('test_number')
#     profile_uname = session.get('username')
#     correct_answers = []
#     wrong_answers = []
#     c = 0
#     w = 0
#
#     cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
#     cur.execute("SELECT uname, uimg FROM signup WHERE uname=%s", (profile_uname,))
#     ulist = cur.fetchall()
#     cur.close()
#
#     cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
#     cur.execute("SELECT * FROM question")
#     questionlist = cur.fetchall()
#     cur.close()
#
#     if request.method == 'POST':
#         for n in range(1, 21):
#             qid_key = f"queid_{n}"
#             question_key = f"question{n}"
#
#             if qid_key in request.form and question_key in request.form:
#                 qid = request.form[qid_key]
#                 answer = request.form[question_key]
#
#                 cur = mysql.connection.cursor()
#                 cur.execute("SELECT * FROM question WHERE id = %s AND ans = %s", (qid, answer))
#                 user = cur.fetchone()
#                 cur.close()
#
#                 if user:
#                     correct_answers.append((qid, answer))
#                     c += 1
#                 else:
#                     wrong_answers.append((qid, answer))
#                     w += 1
#
#         total_question = int(20)
#         total_mark = c * 36
#         attempt = int(c + w)
#
#         cur = mysql.connection.cursor()
#         cur.execute(
#             "INSERT INTO mocktest (test_number, username, result) VALUES (%s, %s, %s)",
#             (test_number, profile_uname,total_mark,))
#         mysql.connection.commit()
#         cur.close()
#
#         # Redirect to a thank you page or any other page after submission
#         return redirect(url_for('user_mock_result',total_mark=total_mark, c=c, w=w, attempt=attempt))
#     # Printing correct and wrong answers
#     print(f"Correct Answers: {c}")
#     for qid, answer in correct_answers:
#         print(f"Question ID: {qid}, Answer: {answer}")
#
#     print(f"Wrong Answers: {w}")
#     for qid, answer in wrong_answers:
#         print(f"Question ID: {qid}, Answer: {answer}")
#
#     # Storing counts in session
#     session['correct_count'] = c
#     session['wrong_count'] = w
#
#     return render_template('user_mock_test.html', ulist=ulist, questionlist=questionlist, correct_answers=correct_answers, wrong_answers=wrong_answers,test_number=test_number)


@app.route('/user_mock_test', methods=['GET', 'POST'])
def user_mock_test():
    test_number = request.args.get('test_number')
    profile_uname = session.get('username')
    correct_answers = []
    wrong_answers = []
    c = 0
    w = 0

    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT uname, uimg FROM signup WHERE uname=%s", (profile_uname,))
    ulist = cur.fetchall()
    cur.close()

    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT * FROM question")
    questionlist = cur.fetchall()
    cur.close()

    if request.method == 'POST':
        for n in range(1, 21):
            qid_key = f"queid_{n}"
            question_key = f"question{n}"

            if qid_key in request.form and question_key in request.form:
                qid = request.form[qid_key]
                answer = request.form[question_key]

                cur = mysql.connection.cursor()
                cur.execute("SELECT * FROM question WHERE id = %s AND ans = %s", (qid, answer))
                user = cur.fetchone()
                cur.close()

                if user:
                    correct_answers.append((qid, answer))
                    c += 1
                else:
                    wrong_answers.append((qid, answer))
                    w += 1

        total_question = 20
        total_mark = c * 10
        attempt = c + w

        # Check if the combination of username and test number already exists in the database
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM mocktest WHERE test_number = %s AND username = %s", (test_number, profile_uname))
        existing_record = cur.fetchone()
        cur.close()

        if existing_record:
            # Update the existing record
            cur = mysql.connection.cursor()
            cur.execute(
                "UPDATE mocktest SET result = %s WHERE test_number = %s AND username = %s",
                (total_mark, test_number, profile_uname)
            )
            mysql.connection.commit()
            cur.close()
        else:
            # Insert a new record
            cur = mysql.connection.cursor()
            cur.execute(
                "INSERT INTO mocktest (test_number, username, result) VALUES (%s, %s, %s)",
                (test_number, profile_uname, total_mark)
            )
            mysql.connection.commit()
            cur.close()

        # Redirect to a thank you page or any other page after submission
        return redirect(url_for('user_mock_result', total_mark=total_mark, c=c, w=w, attempt=attempt))

    # Printing correct and wrong answers
    print(f"Correct Answers: {c}")
    for qid, answer in correct_answers:
        print(f"Question ID: {qid}, Answer: {answer}")

    print(f"Wrong Answers: {w}")
    for qid, answer in wrong_answers:
        print(f"Question ID: {qid}, Answer: {answer}")

    # Storing counts in session
    session['correct_count'] = c
    session['wrong_count'] = w

    return render_template('user_mock_test.html', ulist=ulist, questionlist=questionlist, correct_answers=correct_answers, wrong_answers=wrong_answers, test_number=test_number)




@app.route('/user_mock_result')
def user_mock_result():
    total_mark = request.args.get('total_mark')
    c = request.args.get('c')
    w = request.args.get('w')

    # c = session.get('correct_count', 0)
    # w = session.get('wrong_count', 0)
    profile_uname = session.get('username')

    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT uname, uimg FROM signup WHERE uname=%s", (profile_uname,))
    ulist = cur.fetchall()
    cur.close()

    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT * FROM score ORDER BY date DESC")
    scorelist = cur.fetchall()
    cur.close()

    # total_question = int(20)
    # total_mark = c * 36
    attempt = int(c)+int(w)

    
    print(total_mark)
    print(attempt)
    return render_template('user_mock_result.html',ulist=ulist, scorelist=scorelist,total_mark=total_mark, c=c, w=w, attempt=attempt)


###################################################################################


@app.route('/user-cet-score',methods=['GET', 'POST'])
def usercetscore():
    profile_uname = session.get('username')
    current_date = datetime.now().strftime("%Y-%m-%d")

    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT uname, uimg FROM signup WHERE uname=%s", (profile_uname,))
    ulist = cur.fetchall()
    cur.close()

    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT branch FROM branch_name")
    branchlist = cur.fetchall()
    cur.close()

    average = None

    if request.method == "POST":
        test_1 = request.form['cetscore']
        branch = request.form['txtcast']
        if not test_1:
            flash("Please fill in all required fields.")
        else:
            # Store values in session
            session['cet_score'] = test_1
            session['branch'] = branch
            # Redirect to the next page
            return redirect(url_for('clglist'))

    return render_template('user_cet_college.html',branchlist=branchlist, avg = average, profile_uname=profile_uname, ulist=ulist,  current_date=current_date)


@app.route('/user-neet-score', methods=['GET', 'POST'])
def userneetscore():

    profile_uname = session.get('username')
    current_date = datetime.now().strftime("%Y-%m-%d")

    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT uname, uimg FROM signup WHERE uname=%s", (profile_uname,))
    ulist = cur.fetchall()
    cur.close()

    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT branch FROM branch_name")
    branchlist = cur.fetchall()
    cur.close()

    average = None

    if request.method == "POST":
        test_1 = request.form['cetscore']
        branch = request.form['txtcast']
        if not test_1:
            flash("Please fill in all required fields.")
        else:
            # Store values in session
            session['cet_score'] = test_1
            session['branch'] = branch

            cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
            # Use the correct SQL syntax for inserting data
            cur.execute("INSERT INTO mocktest (username, result) VALUES (%s, %s)", (profile_uname, test_1))
            mysql.connection.commit()  # Don't forget to commit the transaction
            cur.close()

            # Redirect to the next page
            return redirect(url_for('clglist2'))

    return render_template('user_neet_score.html', branchlist=branchlist, avg=average, profile_uname=profile_uname,
                           ulist=ulist, current_date=current_date)


@app.route('/clg-list2')
def clglist2():
    profile_uname = session.get('username')
    cet_score = session.get('cet_score')
    branch = session.get('branch')

    # Fetch user data
    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT uname, uimg FROM signup WHERE uname=%s", (profile_uname,))
    ulist = cur.fetchall()
    cur.close()

    current_date = datetime.now().strftime("%Y-%m-%d")

    # Load the data
    df = pd.read_csv('data.csv')

    # Drop rows with missing target values
    df = df.dropna(subset=['admitted'])

    # Define features and target
    X = df[['college_name', 'branch', 'cutoff_percentile', 'student_percentile']]
    y = df['admitted']

    # Preprocessing
    preprocessor = ColumnTransformer(
        transformers=[
            ('cat', Pipeline(steps=[
                ('imputer', SimpleImputer(strategy='most_frequent')),  # Impute missing categorical data
                ('encoder', OneHotEncoder(handle_unknown='ignore'))
            ]), ['college_name', 'branch']),
            ('num', Pipeline(steps=[
                ('imputer', SimpleImputer(strategy='mean')),  # Impute missing numerical data
                ('scaler', StandardScaler())
            ]), ['cutoff_percentile', 'student_percentile'])
        ]
    )

    # Create a pipeline with preprocessing and logistic regression
    model = Pipeline(steps=[
        ('preprocessor', preprocessor),
        ('classifier', LogisticRegression())
    ])

    # Split data into training and test sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Train the model
    model.fit(X_train, y_train)

    def suggest_colleges(student_percentile, branch, df, model):
        # Prepare input data
        input_data = pd.DataFrame({
            'college_name': df['college_name'].unique(),
            'branch': [branch] * len(df['college_name'].unique()),
            'cutoff_percentile': df['cutoff_percentile'].mean(),  # Example: use average cutoff percentile
            'student_percentile': [student_percentile] * len(df['college_name'].unique())
        })

        # Predict the probability of admission for each college
        probabilities = model.predict_proba(input_data)[:, 1]

        # Add probabilities to the original DataFrame
        suggestions = df[['college_name']].drop_duplicates()
        suggestions['admission_probability'] = probabilities

        # Sort by probability in descending order
        suggestions = suggestions.sort_values(by='admission_probability', ascending=False)

        return suggestions

    # Example usage
    student_percentile = cet_score
    branch_name = branch
    suggested_colleges = suggest_colleges(student_percentile, branch_name, df, model)
    suggested_colleges = suggested_colleges.to_dict(orient='records')

    return render_template('user_clg_list2.html', suggested_colleges=suggested_colleges, profile_uname=profile_uname, ulist=ulist, current_date=current_date)



if __name__ == '__main__':
    app.run(debug=True)  # Enable debug mode for development