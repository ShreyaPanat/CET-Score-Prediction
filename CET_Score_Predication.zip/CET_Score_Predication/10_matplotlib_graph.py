# HOW TO ADD VALUE IN DATA THROUGH IN BAR OR LINR BAR

import matplotlib.pyplot as plt
import numpy as np

#sample data
caterogy = ['category_1', 'category_2', 'category_3']
values = [15, 25, 30]

for i, value in enumerate(values):
    plt.text(i, value + 1, str(value), ha='center', va='bottom')

plt.bar(caterogy, values)
plt.show()

